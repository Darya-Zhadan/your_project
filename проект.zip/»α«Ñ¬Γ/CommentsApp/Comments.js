class Comments extends React.Component {
	constructor(props) {
		super(props);

		this.Form = this.Form.bind(this);
		this._submit = this._submit.bind(this);
		this._update = this._update.bind(this);

		this.state = {
			authors: [
				{
					name: 'Alex',
					avatarUrl: 'https://via.placeholder.com/150',
					text: 'Magni quaerat modi, veritatis molestias harum laboriosam! Ut dignissimos a velit, blanditiis fugit sed deleniti illum recusandae repellendus voluptatibus, tempora excepturi vel!',
				},
				{
					name: 'Bob',
					avatarUrl: 'https://via.placeholder.com/100',
					text: 'Doloremque magnam numquam quas, ipsa est ad eveniet expedita aliquid? Odio reiciendis eligendi exercitationem dolorem et cupiditate incidunt necessitatibus labore, alias nostrum.',
				},
			],
			list: <span>Комментариев нет</span>
		};
	}

	componentDidMount() {
		this._update();
	}

	Form = function(props) {
		return (
			<form className="comments__form form" action="" method="post" onSubmit={this._submit}>
				<div className="form__field"><input type="text" name="name" placeholder="Ваше имя" defaultValue="Peter" /></div>
				<div className="form__field"><input type="text" name="avatarUrl" placeholder="Адрес аватарки" defaultValue="https://via.placeholder.com/100" /></div>
				<div className="form__field"><textarea name="text" placeholder="Ваш комментарий">Magni quaerat modi, veritatis molestias harum laboriosam</textarea></div>
				<button>Отправить</button>
			</form>
		);
	}

	Comment = function(props) {
		return (
			<div className="comments__item comment">
				<img className="comment__avatar" src={props.author.avatarUrl} />
				<div className="comment__name">{props.author.name}</div>
				<div className="comment__text">{props.author.text}</div>
			</div>
		);
	}

	_update = function(authors) {
		let list = this.state.authors.map((author, i) => (
				<this.Comment key={i} author={author} />
			)
		);

		this.setState({list: list});
	}

	_submit = function(event) {
		event.preventDefault();

		let form = event.target;
		if (!form) return false;

		let name = form.querySelector('input[name="name"]').value,
			avatarUrl = form.querySelector('input[name="avatarUrl"]').value,
			text = form.querySelector('textarea[name="text"]').value;

		let authors = this.state.authors;

		authors.push({
			name: name,
			avatarUrl: avatarUrl,
			text: text,
		});

		this._update(authors);
	}

	render() {
		return (
			<div className="comments">
				<h1>{this.props.children}</h1>
				<this.Form />
				<hr />
				<div className="comments__list">
					{this.state.list}
				</div>
			</div>
		);
	}
}

ReactDOM.render(
	<Comments>Оставить комментарий</Comments>,
	document.getElementById('app')
);